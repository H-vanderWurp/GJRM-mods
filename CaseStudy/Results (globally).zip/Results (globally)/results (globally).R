## look at results
## Home Office:
#setwd("E:/Uni Arbeit/Sciebo/Dissertation/Auswertungen/github CaseStudy/Results (globally)")
## Buero:
#setwd("C:/Users/vanderwurp/Desktop/Sciebo/Dissertation/Auswertungen/github CaseStudy/Results (globally)")

getres <- function(Name){
  setwd(Name)
  n <- c()
  lf <- list.files()
  ResT <- NULL
  n <- 0
  bets <- 0
  bet.gains <- 0
  for(i in lf){
    load(i)
    ResT <- rbind(ResT, Res[[1]])
    bets <- bets + Res[[2]]
    bet.gains <- bet.gains + sum(Res[[3]], na.rm = TRUE)
    n <- n + length(Res[[1]]$rps) - sum(is.na(Res[[1]]$rps))
    rm(Res)
  }
  setwd("../..")
  res <- as.data.frame(t(apply(ResT[,1:5], 2, function(x) mean(x, na.rm = TRUE))))
  res$n <- n
  res$bets <- bets
  res$bet.gains <- bet.gains
  return(res)
}

getres2 <- function(Name){
  setwd(Name)
  n <- c()
  lf <- list.files()
  ResT <- NULL
  n <- 0
  bets <- 0
  bet.gains <- 0
  for(i in lf){
    load(i)
    ResT <- rbind(ResT, Res[[1]])
    bets <- bets + Res[[2]]
    bet.gains <- bet.gains + sum(Res[[3]], na.rm = TRUE)
    n <- n + length(Res[[1]]$rps) - sum(is.na(Res[[1]]$rps))
    rm(Res)
  }
  setwd("..")
  res <- as.data.frame(t(apply(ResT[,1:5], 2, function(x) mean(x, na.rm = TRUE))))
  res$n <- n
  res$bets <- bets
  res$bet.gains <- bet.gains
  return(res)
}


getres.lasso <- function(Name){
  setwd(Name)
  n <- 0
  lf <- list.files()
  ResTAIC <- ResTBIC <- NULL
  nAIC <- nBIC <- 0
  betsAIC <- betsBIC <- 0
  gainsAIC <- gainsBIC <- 0
  for(i in lf){
    load(i)
    ResTAIC <- rbind(ResTAIC, Res[[1]])
    ResTBIC <- rbind(ResTBIC, Res[[2]])
    betsAIC <- betsAIC + Res[[3]]
    betsBIC <- betsBIC + Res[[4]]
    gainsAIC <- gainsAIC + sum(Res[[5]], na.rm = TRUE)
    gainsBIC <- gainsBIC + sum(Res[[6]], na.rm = TRUE)
    n <- n + length(Res[[1]]$rps) - sum(is.na(Res[[1]]$rps))
    rm(Res)
  }
  setwd("../..")
  resAIC <- as.data.frame(t(apply(ResTAIC[,1:5], 2, function(x) mean(x, na.rm = TRUE))))
  resBIC <- as.data.frame(t(apply(ResTBIC[,1:5], 2, function(x) mean(x, na.rm = TRUE))))
  resAIC$n <- n
  resAIC$bets <- betsAIC
  resAIC$bet.gains <- gainsAIC
  resBIC$n <- n
  resBIC$bets <- betsBIC
  resBIC$bet.gains <- gainsBIC
  return(rbind(resAIC, resBIC))
}


getres.full <- function(file){
  load(file)
  res <- as.data.frame(t(apply(Res[[1]][,1:5], 2, function(x) mean(x, na.rm = TRUE))))
  res$n <- length(Res[[1]]$rps - sum(is.na(Res[[1]]$rps)))
  res$bets <- Res[[2]]
  res$bet.gains <- sum(Res[[3]], na.rm = TRUE)
  return(res)
}

pois <- getres.full("pois.rData")
pois_both <- getres.full("pois_both.rData")
pois_lasso <- getres.full("pois_lasso.rData")
pois_lasso_both <- getres.full("pois_lasso_both.rData")

cop_F <- getres("Cop/F")
cop_FGM <- getres("Cop/FGM")

cop_F_both <- getres("Cop_both/F")
cop_FGM_both <- getres("Cop_both/FGM")

cop_F_equal <- getres("Cop_equal/F")
cop_FGM_equal <- getres("Cop_equal/FGM")

cop_F_equal_both <- getres("Cop_equal_both/F")
cop_FGM_equal_both <- getres("Cop_equal_both/FGM")

zw <- getres.lasso("Cop_lasso/F")
cop_F_lasso_AIC <- zw[1,]
cop_F_lasso_BIC <- zw[2,]
rm(zw)
zw <- getres.lasso("Cop_lasso/FGM")
cop_FGM_lasso_AIC <- zw[1,]
cop_FGM_lasso_BIC <- zw[2,]
rm(zw)

zw <- getres.lasso("Cop_lasso_both/F")
cop_F_lasso_AIC_both <- zw[1,]
cop_F_lasso_BIC_both <- zw[2,]
rm(zw)
zw <- getres.lasso("Cop_lasso_both/FGM")
cop_FGM_lasso_AIC_both <- zw[1,]
cop_FGM_lasso_BIC_both <- zw[2,]
rm(zw)

zw <- getres.lasso("Cop_fat/F")
cop_F_fat_AIC <- zw[1,]
cop_F_fat_BIC <- zw[2,]
rm(zw)
zw <- getres.lasso("Cop_fat/FGM")
cop_FGM_fat_AIC <- zw[1,]
cop_FGM_fat_BIC <- zw[2,]
rm(zw)

zw <- getres.lasso("Cop_fat_both/F")
cop_F_fat_AIC_both <- zw[1,]
cop_F_fat_BIC_both <- zw[2,]
rm(zw)
zw <- getres.lasso("Cop_fat_both/FGM")
cop_FGM_fat_AIC_both <- zw[1,]
cop_FGM_fat_BIC_both <- zw[2,]
rm(zw)


ordinal <- getres2("ordinal")

RF <- getres2("RF")
RF_both <- getres2("RF_both")

XGboost <- getres2("xgboost")
XGboost_both <- getres2("xgboost_both")



## summary table without leagues. Simple averaged through leagues.

## Table XX
X <- rbind(pois, pois_both, pois_lasso, pois_lasso_both,
           RF, RF_both, XGboost, XGboost_both, 
           cop_F, cop_FGM, cop_F_both, cop_FGM_both,
           cop_F_equal, cop_FGM_equal, cop_F_equal_both, cop_FGM_equal_both,
           cop_F_lasso_AIC, cop_F_lasso_BIC, cop_FGM_lasso_AIC, cop_FGM_lasso_BIC,
           cop_F_lasso_AIC_both, cop_F_lasso_BIC_both, cop_FGM_lasso_AIC_both, cop_FGM_lasso_BIC_both,
           cop_F_fat_AIC, cop_F_fat_BIC, cop_FGM_fat_AIC, cop_FGM_fat_BIC,
           cop_F_fat_AIC_both, cop_F_fat_BIC_both, cop_FGM_fat_AIC_both, cop_FGM_fat_BIC_both,
           ordinal)




Model <- c(rep("pois", 4), rep("RF", 2), rep("XGboost", 2), rep("Cop", 8),
           rep(c("Cop AIC", "Cop BIC"), 8), "ordinal")
Eq <- c(1,2,1,2,1,2,1,2,1,1,2,2,1,1,2,2,1,1,1,1,2,2,2,2,1,1,1,1,2,2,2,2,NA)
regul <- c("-", "-", rep("LASSO", 2), rep("-", 8), rep("equal", 4), rep("LASSO", 8), rep("both", 8), "-")
Cop <- c(rep("-", 8), rep(c("F", "FGM"), 4), rep(c("F","F","FGM","FGM"), 4), "-")
t1 <- cbind(Model, Eq, Cop, regul, X)
rownames(t1) <- NULL

X <- cbind(X, gainratio = X[,8]/X[,7])
t1$gainratio <- X$gainratio

t1 <- t1[,-c(10,12)]

## Table A.4
library(xtable)
print(xtable(t1, digits = c(0, 0, 0, 0, 0, 4, 3, 3, 3, 3, 0, 4)), include.rownames = FALSE)

