## look at results
## Home Office:
#setwd("E:/Uni Arbeit/WM_Modellierungen/Projekt III/web scraping/Fitting")
## Buero:
#setwd("//store/vanderwurp/WM_Modellierungen/Projekt III/web scraping/Fitting")

getres <- function(Name){
  Ligen <- c("BPL", "BL", "LaLi", "Lig1", "SerA", "ED", "TurL")
  setwd(Name)
  n <- c()
  for(Liga in Ligen){
    load(paste0("Res_", Liga, ".rData"))
    assign(Liga, Res)
    n <- c(n, length(Res[[1]]$rps) - sum(is.na(Res[[1]]$rps)))
    rm(Res)
  }
  setwd("..")
  
  D <- list(BPL, BL, LaLi, Lig1, SerA, ED, TurL)
  
  res <- sapply(D, function(Dat){
    apply(Dat[[1]], 2, function(x) mean(x, na.rm = TRUE))
  })
  res <- res[1:5,]  
  dimnames(res)[[2]] <- Ligen
  
  res <- rbind(res, n)
  
  res <- rbind(res, sapply(D, function(Dat){
    Dat[[2]]
  }))
  
  res <- rbind(res, sapply(D, function(Dat){
    sum(Dat[[3]], na.rm = TRUE)
  }))
  
  dimnames(res)[[1]][6:8] <- c("n" ,"bets", "bet.gains")
  return(t(res))
}

getres.cop <- function(dir, Cop){
  Ligen <- c("BPL", "BL", "LaLi", "Lig1", "SerA", "ED", "TurL")
  setwd(dir)
  n <- c()
  for(Liga in Ligen){
    load(paste0("Res_", Liga, "_", Cop, ".rData"))
    assign(Liga, Res)
    n <- c(n, length(Res[[1]]$rps) - sum(is.na(Res[[1]]$rps)))
    rm(Res)
  }
  setwd("..")
  
  D <- list(BPL, BL, LaLi, Lig1, SerA, ED, TurL)
  
  res <- sapply(D, function(Dat){
    apply(Dat[[1]], 2, function(x) mean(x, na.rm = TRUE))
  })
  res <- res[1:5,]  
  dimnames(res)[[2]] <- Ligen
  
  res <- rbind(res, n)
  
  res <- rbind(res, sapply(D, function(Dat){
    Dat[[2]]
  }))
  
  res <- rbind(res, sapply(D, function(Dat){
    sum(Dat[[3]], na.rm = TRUE)
  }))
  
  dimnames(res)[[1]][6:8] <- c("n" ,"bets", "bet.gains")
  return(t(res))
}

getres.cop.lasso <- function(dir, Cop){
  Ligen <- c("BPL", "BL", "LaLi", "Lig1", "SerA", "ED", "TurL")
  setwd(dir)
  fullres <- NULL
  for(Liga in Ligen){
    nAIC.liga <- nBIC.liga <- 0
    ResAIC <- ResBIC <- NULL
    n.bets.AIC <- n.bets.BIC <- 0
    gainsAIC <- gainsBIC <- 0
    setwd(paste0(Liga, "_", Cop))
    for(fi in list.files()){
      load(fi)
      ResAIC <- rbind(ResAIC, Res[[1]])
      ResBIC <- rbind(ResBIC, Res[[2]])
      n.bets.AIC <- n.bets.AIC + Res[[3]]
      n.bets.BIC <- n.bets.BIC + Res[[4]]
      gainsAIC <- gainsAIC + Res[[5]]
      gainsBIC <- gainsBIC + Res[[6]]
      nAIC.liga <- nAIC.liga + sum(!is.na(Res[[1]]$rps))
      nBIC.liga <- nBIC.liga + sum(!is.na(Res[[2]]$rps))
      rm(Res)
    }
    setwd("..")
    tempres <- data.frame(rps = c(mean(ResAIC$rps, na.rm = TRUE),
                                  mean(ResBIC$rps, na.rm = TRUE)),
                          mllh = c(mean(ResAIC$mllh, na.rm = TRUE),
                                   mean(ResBIC$mllh, na.rm = TRUE)),
                          cr = c(mean(ResAIC$cr, na.rm = TRUE),
                                 mean(ResBIC$cr, na.rm = TRUE)),
                          SE = c(mean(ResAIC$SE, na.rm = TRUE),
                                 mean(ResBIC$SE, na.rm = TRUE)),
                          AE = c(mean(ResAIC$AE, na.rm = TRUE),
                                 mean(ResBIC$AE, na.rm = TRUE)),
                          n = c(nAIC.liga, nBIC.liga),
                          bets = c(n.bets.AIC, n.bets.BIC),
                          bet.gains = c(gainsAIC, gainsBIC),
                          Model = c("AIC", "BIC"),
                          Liga = Liga)
    fullres <- rbind(fullres, tempres)
  }
  setwd("..")
  return(fullres)
}

getres.fat <- function(dir){
  setwd(dir)
  ordner <- list.files()
  Global <- data.frame()
  errors <- 0
  for (k in ordner){
    setwd(k)
    dateien <- list.files()
    load(dateien[1]) ## named Res
    
    ResglobalAIC <- Res$ResAIC
    ResglobalBIC <- Res$ResBIC
    n.bets.AIC <- Res$n.betsAIC
    n.bets.BIC <- Res$n.betsBIC
    betAIC <- sum(Res$gainsAIC)
    betBIC <- sum(Res$gainsBIC)
    rm(Res)
    for (i in dateien[-1]){
      load(i)
      errors <- errors + Res$errors
      ResglobalAIC <- rbind(ResglobalAIC, Res$ResAIC)
      ResglobalBIC <- rbind(ResglobalBIC, Res$ResBIC)
      n.bets.AIC <- n.bets.AIC + Res$n.betsAIC
      n.bets.BIC <- n.bets.BIC + Res$n.betsBIC
      betAIC <- betAIC + sum(Res$gainsAIC)
      betBIC <- betBIC + sum(Res$gainsBIC)
      rm(Res)
    }
    
    ## 
    AIChere <- data.frame(rps = mean(ResglobalAIC$rps, na.rm = TRUE),
                          mllh = mean(ResglobalAIC$mllh, na.rm = TRUE),
                          cr = mean(ResglobalAIC$cr, na.rm = TRUE),
                          SE = mean(ResglobalAIC$SE, na.rm = TRUE),
                          AE = mean(ResglobalAIC$AE, na.rm = TRUE),
                          n = length(ResglobalAIC$rps) - sum(is.na(ResglobalAIC$rps)),
                          bets = n.bets.AIC,
                          gains = betAIC,
                          Liga = sub("_.*", "", k),
                          cop = sub(" .*" , "", sub(".*_", "", k)),
                          model = "AIC")
    BIChere <- data.frame(rps = mean(ResglobalBIC$rps, na.rm = TRUE),
                          mllh = mean(ResglobalBIC$mllh, na.rm = TRUE),
                          cr = mean(ResglobalBIC$cr, na.rm = TRUE),
                          SE = mean(ResglobalBIC$SE, na.rm = TRUE),
                          AE = mean(ResglobalBIC$AE, na.rm = TRUE),
                          n = length(ResglobalBIC$rps) - sum(is.na(ResglobalBIC$rps)),
                          bets = n.bets.BIC,
                          gains = betBIC,
                          Liga = sub("_.*", "", k),
                          cop = sub(" .*" , "", sub(".*_", "", k)),
                          model = "BIC")
    Global <- rbind(Global, AIChere)
    Global <- rbind(Global, BIChere)
    setwd("..")
  }
  setwd("..")
  return(list(Global, errors))
}

pois <- getres("pois")
pois_both <- getres("pois_both")
pois_lasso <- getres("pois_lasso")
pois_lasso_both <- getres("pois_lasso_both")

cops <- c("F", "FGM")
cop <- lapply(cops, function(cop) getres.cop("cop", cop))
cop <- as.data.frame(do.call("rbind", cop))
cop$Liga <- rep(c("BPL", "BL", "LaLi", "Lig1", "SerA", "ED", "TurL"), 2)
cop$cop <- rep(c("F", "FGM"), each = 7)
rownames(cop) <- NULL

cop_both <- lapply(cops, function(cop) getres.cop("cop_both", cop))
cop_both <- as.data.frame(do.call("rbind", cop_both))
cop_both$Liga <- rep(c("BPL", "BL", "LaLi", "Lig1", "SerA", "ED", "TurL"), 2)
cop_both$cop <- rep(c("F", "FGM"), each = 7)
rownames(cop_both) <- NULL

## cop equal
cop_equal <- lapply(cops, function(cop) getres.cop("cop_equal", cop))
cop_equal <- as.data.frame(do.call("rbind", cop_equal))
cop_equal$Liga <- rep(c("BPL", "BL", "LaLi", "Lig1", "SerA", "ED", "TurL"), 2)
cop_equal$cop <- rep(c("F", "FGM"), each = 7)
rownames(cop_equal) <- NULL

## cop equal both
cop_equal_both <- lapply(cops, function(cop) getres.cop("cop_equal_both", cop))
cop_equal_both <- as.data.frame(do.call("rbind", cop_equal_both))
cop_equal_both$Liga <- rep(c("BPL", "BL", "LaLi", "Lig1", "SerA", "ED", "TurL"), 2)
cop_equal_both$cop <- rep(c("F", "FGM"), each = 7)
rownames(cop_equal_both) <- NULL

## lasso
cop_lasso_F <- getres.cop.lasso("cop_lasso", "F")
cop_lasso_FGM <- getres.cop.lasso("cop_lasso", "FGM")
cop_lasso_both_F <- getres.cop.lasso("cop_lasso_both", "F")
cop_lasso_both_FGM <- getres.cop.lasso("cop_lasso_both", "FGM")

## fatmodel
cop_fat_F <- getres.cop.lasso("cop_fat", "F")
cop_fat_FGM <- getres.cop.lasso("cop_fat", "FGM")
cop_fat_both_F <- getres.cop.lasso("cop_fat_both", "F")
cop_fat_both_FGM <- getres.cop.lasso("cop_fat_both", "FGM")


ordinal <- getres("ordinal")

RF <- getres("RF")
RF_both <- getres("RF_both")

XGboost <- getres("xgboost")
XGboost_both <- getres("xgboost_both")



## summary table without leagues. weighted averages

## function ave gathers averages of rps, mllh etc., and sums of n, bets etc.

ave1 <- function(tab){
  a <- apply(tab[,1:5], 2, function(x) {sum(x * tab[,6])/sum(tab[,6])})
  b <- apply(tab[,6:8], 2, sum)
  return(c(a,b))
}

## 2nd version fuer einzelne Ligen:

ave2 <- function(tab, Liga = "TurL"){
  here <- tab[rownames(tab) == Liga ,]
  if(is.data.frame(here)){
    here <- tab[tab$Liga == Liga,]
  }
  names(here)[8] <- "bet.gains"
  return(here[-(9:11)])
}


Ligen <- c("BPL", "BL", "LaLi", "Lig1", "SerA", "ED", "TurL")
## Table 5.3
t(sapply(Ligen, function(L) ave2(pois, Liga = L)))


X <- rbind(ave1(pois), ave1(pois_both), ave1(pois_lasso), ave1(pois_lasso_both),
      ave1(RF), ave1(RF_both), ave1(XGboost), ave1(XGboost_both),
      ave1(cop[1:7,]), ave1(cop[8:14,]), # cop: F, FGM
      ave1(cop_both[1:7,]), ave1(cop_both[8:14,]),
      ave1(cop_equal[1:7,]), ave1(cop_equal[8:14,]),
      ave1(cop_equal_both[1:7,]), ave1(cop_equal_both[8:14,]),
      ave1(cop_lasso_F[seq(1, 14, 2), ]),      #AIC
      ave1(cop_lasso_F[seq(2, 14, 2), ]),      #BIC
      ave1(cop_lasso_FGM[seq(1, 14, 2), ]),    #AIC
      ave1(cop_lasso_FGM[seq(2, 14, 2), ]),    #BIC
      ave1(cop_lasso_both_F[seq(1, 14, 2), ]), #AIC
      ave1(cop_lasso_both_F[seq(2, 14, 2), ]),  #BIC
      ave1(cop_lasso_both_FGM[seq(1, 14, 2), ]),#AIC
      ave1(cop_lasso_both_FGM[seq(2, 14, 2), ]), #BIC
      ave1(cop_fat_F[seq(1, 14, 2), ]), #AIC
      ave1(cop_fat_F[seq(2, 14, 2), ]), #BIC
      ave1(cop_fat_FGM[seq(1, 14, 2), ]), #AIC
      ave1(cop_fat_FGM[seq(2, 14, 2), ]), #BIC
      ave1(cop_fat_both_F[seq(1, 14, 2), ]), #AIC
      ave1(cop_fat_both_F[seq(2, 14, 2), ]), #BIC
      ave1(cop_fat_both_FGM[seq(1, 14, 2), ]), #AIC
      ave1(cop_fat_both_FGM[seq(2, 14, 2), ]), #BIC
      ave1(ordinal))
dimnames(X)[[1]] <- c("pois", "pois_both", "pois_lasso", "pois_lasso_both",
                      "RF", "RF_both", "XGboost", "XGboost_both",
                      "Cop F", "Cop FGM",
                      "Cop_both F", "Cop_both FGM",
                      "Cop_equal F", "Cop_equal FGM",
                      "Cop_equal_both F", "Cop_equal_both FGM",
                      "Cop_lasso AIC F", "Cop_lasso BIC F",
                      "Cop_lasso AIC FGM", "Cop_lasso BIC FGM",
                      "Cop_lasso_both AIC F", "Cop_lasso_both BIC F",
                      "Cop_lasso_both AIC FGM", "Cop_lasso_both BIC FGM",
                      "Fat AIC F", "Fat BIC F", "Fat AIC FGM", "Fat BIC FGM",
                      "Fat_both AIC F", "Fat_both BIC F", "Fat_both AIC FGM", "Fat_both BIC FGM",
                      "ordinal")

Model <- c(rep("pois", 4), rep("RF", 2), rep("XGboost", 2), rep("Cop", 8),
           rep(c("Cop AIC", "Cop BIC"), 8), "ordinal")
Eq <- c(1,2,1,2,1,2,1,2,1,1,2,2,1,1,2,2,1,1,1,1,2,2,2,2,1,1,1,1,2,2,2,2,NA)
regul <- c("-", "-", rep("LASSO", 2), rep("-", 8), rep("equal", 4), rep("LASSO", 8), rep("both", 8), "-")
Cop <- c(rep("-", 8), rep(c("F", "FGM"), 4), rep(c("F","F","FGM","FGM"), 4), "-")
t1 <- cbind(Model, Eq, Cop, regul, X)
rownames(t1) <- NULL

X <- cbind(X, gainratio = X[,8]/X[,7])
X <- as.data.frame(X[,-c(6,8)])

X$Model <- c(rep("pois", 4), rep("RF", 2), rep("XGboost", 2), rep("Cop", 8), rep(c("Cop AIC", "Cop BIC"), 8),
             "ordinal")
X$Eq <- c(rep(c(1,2), 4), 1,1,2,2,1,1,2,2, rep(1,4), rep(2,4), rep(1,4), rep(2,4), "-")
X$Copula <- c(rep("-", 8), rep(c("F", "FGM"), 4), rep(c("F", "F", "FGM", "FGM"), 4), "-")
X$reg <- c(rep("-", 2), rep("LASSO", 2), rep("-", 8), rep("equal", 4), rep("LASSO", 8),
           rep("both", 8), "-")
X <- X[,c(8:11, 1:7)]

## Table 5.4
library(xtable)
print(xtable(X, digits = c(0, 0, 0, 0, 4, 4, 3, 3, 3, 3, 0, 4)), include.rownames = FALSE)


## Table A.1

tab <- t(cbind(pois[,1], pois_both[,1], pois_lasso[,1], pois_lasso_both[,1],
        RF[,1], RF_both[,1], XGboost[,1], XGboost_both[,1],
        cop[1:7,1], cop[8:14,1], cop_both[1:7, 1], cop_both[8:14, 1],
        cop_equal[1:7, 1], cop_equal[8:14, 1], cop_equal_both[1:7, 1], cop_equal_both[8:14, 1],
        cop_lasso_F[seq(1,14, by = 2), 1], cop_lasso_F[seq(2,14, by = 2), 1],
        cop_lasso_FGM[seq(1,14, by = 2), 1], cop_lasso_FGM[seq(2,14, by = 2), 1],
        cop_lasso_both_F[seq(1,14, by = 2), 1], cop_lasso_both_F[seq(2,14,by=2), 1],
        cop_lasso_both_FGM[seq(1,14, by = 2), 1], cop_lasso_both_FGM[seq(2,14, by = 2), 1],
        cop_fat_F[seq(1,14, by = 2), 1], cop_fat_F[seq(2,14, by = 2),1],
        cop_fat_FGM[seq(1,14, by = 2), 1], cop_fat_FGM[seq(2,14, by = 2), 1],
        cop_fat_both_F[seq(1,14, by = 2), 1], cop_fat_both_F[seq(2,14, by = 2), 1],
        cop_fat_both_FGM[seq(1,14, by = 2), 1], cop_fat_both_FGM[seq(2,14, by = 2), 1],
        ordinal[,1]))
tab <- as.data.frame(tab)
tab$Model <- c(rep("pois", 4), rep("RF", 2),  rep("XGboost", 2), rep("Cop", 8), rep(c("Cop AIC", "Cop BIC"), 8), "ordinal")
tab$Eq <- c(rep(c(1,2), 4), rep(c(1,1,2,2), 2), rep(1,4), rep(2,4), rep(1,4), rep(2,4), NA)
tab$Cop <- c(rep("-", 8), rep(c("F", "FGM"), 4), rep(c("F","F","FGM","FGM"), 4),  NA)
tab$regul <- c("-", "-", "LASSO", "LASSO", rep("-", 8), rep("equal", 4), rep("LASSO", 8), rep("both", 8), NA)
tab <- tab[,c(8:11, 1:7)]
library(xtable)
print(xtable(tab, digits = c(0,0,0,0,0, rep(3, 7))), include.rownames = FALSE)

## Table A.2
tab <- t(cbind(pois[,8] / pois[,7], pois_both[,8] / pois_both[,7], 
               pois_lasso[,8] / pois_lasso[,7], pois_lasso_both[,8] / pois_lasso_both[,7],
               RF[,8] / RF[,7], RF_both[,8] / RF_both[,7], XGboost[,8] / XGboost[,7],  XGboost_both[,8] / XGboost_both[,7],
               cop[1:7,8] / cop[1:7,7], cop[8:14,8] / cop[8:14,7], cop_both[1:7, 8] / cop_both[1:7, 7], cop_both[8:14, 8] / cop_both[8:14, 7],
               cop_equal[1:7, 8] / cop_equal[1:7, 7], cop_equal[8:14, 8] / cop_equal[8:14, 7], 
               cop_equal_both[1:7, 8] / cop_equal_both[1:7, 7], cop_equal_both[8:14, 8] / cop_equal_both[8:14, 7],
               cop_lasso_F[seq(1,14, by = 2), 8] / cop_lasso_F[seq(1,14, by = 2), 7], 
               cop_lasso_F[seq(2,14, by = 2), 8] / cop_lasso_F[seq(2,14, by = 2), 7],
               cop_lasso_FGM[seq(1,14, by = 2), 8] / cop_lasso_FGM[seq(1,14, by = 2), 7], 
               cop_lasso_FGM[seq(2,14, by = 2), 8] / cop_lasso_FGM[seq(2,14, by = 2), 7],
               cop_lasso_both_F[seq(1,14, by = 2), 8] / cop_lasso_both_F[seq(1,14, by = 2), 7], 
               cop_lasso_both_F[seq(2,14,by=2), 8] / cop_lasso_both_F[seq(2,14,by=2), 7],
               cop_lasso_both_FGM[seq(1,14, by = 2), 8] / cop_lasso_both_FGM[seq(1,14, by = 2), 7], 
               cop_lasso_both_FGM[seq(2,14, by = 2), 8] / cop_lasso_both_FGM[seq(2,14, by = 2), 7],
               cop_fat_F[seq(1,14, by = 2), 8] / cop_fat_F[seq(1,14, by = 2), 7], 
               cop_fat_F[seq(2,14, by = 2),8] / cop_fat_F[seq(2,14, by = 2),7],
               cop_fat_FGM[seq(1,14, by = 2), 8] / cop_fat_FGM[seq(1,14, by = 2), 7], 
               cop_fat_FGM[seq(2,14, by = 2), 8] / cop_fat_FGM[seq(2,14, by = 2), 7],
               cop_fat_both_F[seq(1,14, by = 2), 8] / cop_fat_both_F[seq(1,14, by = 2), 7], 
               cop_fat_both_F[seq(2,14, by = 2), 8] / cop_fat_both_F[seq(2,14, by = 2), 7],
               cop_fat_both_FGM[seq(1,14, by = 2), 8] / cop_fat_both_FGM[seq(1,14, by = 2), 7], 
               cop_fat_both_FGM[seq(2,14, by = 2), 8] / cop_fat_both_FGM[seq(2,14, by = 2), 7],
               ordinal[,8] / ordinal[,7]))
tab <- as.data.frame(tab)
tab$Model <- c(rep("pois", 4), rep("RF", 2),  rep("XGboost", 2), rep("Cop", 8), rep(c("Cop AIC", "Cop BIC"), 8), "ordinal")
tab$Eq <- c(rep(c(1,2), 4), rep(c(1,1,2,2), 2), rep(1,4), rep(2,4), rep(1,4), rep(2,4), NA)
tab$Cop <- c(rep("-", 8), rep(c("F", "FGM"), 4), rep(c("F","F","FGM","FGM"), 4),  NA)
tab$regul <- c("-", "-", "LASSO", "LASSO", rep("-", 8), rep("equal", 4), rep("LASSO", 8), rep("both", 8), NA)
tab <- tab[,c(8:11, 1:7)]
library(xtable)
print(xtable(tab, digits = c(0,0,0,0,0, rep(3, 7))), include.rownames = FALSE)


## Table 5.3
pois



